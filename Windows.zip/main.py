import os  # Import the os module
import subprocess

def install_dependencies():
  """Installs dependencies using subprocess."""
  pip_install_cmds = [
      ["pip", "install", "windows-curses"],
      ["pip", "install", "google-generativeai"],
  ]

  for cmd in pip_install_cmds:
    subprocess.run(cmd, check=True)

print("hello world")

def run_code_py():
    """Executes code.py using subprocess."""
    code_path = os.path.join(os.path.dirname(__file__), "code.py")  # Use relative path
    subprocess.run(["python", code_path])

if __name__ == "__main__":
    install_dependencies()
    run_code_py()